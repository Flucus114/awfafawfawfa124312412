package com.voiddevourer.client.model;

import com.voiddevourer.VoidDevourerMod;
import com.voiddevourer.entity.DevourerEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class DevourerModel extends HierarchicalModel<DevourerEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(VoidDevourerMod.MODID, "void_devourer"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart core;

    public DevourerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.leftArm = body.getChild("left_arm");
        this.rightArm = body.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.core = body.getChild("core");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-7, -9, -4, 14, 18, 8)
                        .texOffs(0, 90).addBox(-8, -7, 3, 16, 15, 2),
                PartPose.offset(0, 5, 0));
        body.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-5, -6, -5, 10, 10, 9)
                        .texOffs(48, 20).addBox(-7, -12, -3, 3, 8, 3)
                        .texOffs(60, 20).addBox(4, -14, -3, 3, 10, 3),
                PartPose.offset(0, -8, -1));
        body.addOrReplaceChild("left_arm",
                CubeListBuilder.create()
                        .texOffs(72, 0).addBox(-2, -1, -3, 5, 19, 6)
                        .texOffs(72, 28).addBox(-3, 14, -4, 7, 6, 8),
                PartPose.offset(8, -5, 0));
        body.addOrReplaceChild("right_arm",
                CubeListBuilder.create()
                        .texOffs(96, 0).addBox(-3, -1, -3, 7, 22, 7)
                        .texOffs(96, 30).addBox(-4, 16, -4, 9, 7, 9),
                PartPose.offset(-8, -5, 0));
        body.addOrReplaceChild("core",
                CubeListBuilder.create().texOffs(0, 42)
                        .addBox(-3, -4, -1, 6, 8, 3),
                PartPose.offset(0, 0, -4.5F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, 62).addBox(-3, 0, -3, 6, 15, 6),
                PartPose.offset(4, 9, 0));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(24, 62).addBox(-3, 0, -3, 6, 15, 6),
                PartPose.offset(-4, 9, 0));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(DevourerEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float)Math.PI / 180F);
        head.xRot = headPitch * ((float)Math.PI / 180F);
        leftArm.xRot = Mth.cos(limbSwing * 0.6662F) * 0.8F * limbSwingAmount;
        rightArm.xRot = Mth.cos(limbSwing * 0.6662F + (float)Math.PI) * 0.8F * limbSwingAmount;
        leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.0F * limbSwingAmount;
        rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.0F * limbSwingAmount;
        body.y = 5 + Mth.sin(ageInTicks * 0.08F) * 0.35F;
        core.xRot = ageInTicks * 0.04F;
    }

    @Override
    public ModelPart root() { return root; }
}
