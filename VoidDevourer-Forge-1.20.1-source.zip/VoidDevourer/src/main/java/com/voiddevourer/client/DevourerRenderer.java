package com.voiddevourer.client;

import com.voiddevourer.VoidDevourerMod;
import com.voiddevourer.client.model.DevourerModel;
import com.voiddevourer.entity.DevourerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DevourerRenderer extends MobRenderer<DevourerEntity, DevourerModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VoidDevourerMod.MODID, "textures/entity/void_devourer.png");

    public DevourerRenderer(EntityRendererProvider.Context context) {
        super(context, new DevourerModel(context.bakeLayer(DevourerModel.LAYER_LOCATION)), 1.1F);
    }

    @Override
    public ResourceLocation getTextureLocation(DevourerEntity entity) {
        return TEXTURE;
    }
}
