package com.voiddevourer.registry;

import com.voiddevourer.VoidDevourerMod;
import com.voiddevourer.entity.DevourerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, VoidDevourerMod.MODID);

    public static final RegistryObject<EntityType<DevourerEntity>> VOID_DEVOURER =
            ENTITY_TYPES.register("void_devourer", () -> EntityType.Builder
                    .of(DevourerEntity::new, MobCategory.MONSTER)
                    .sized(1.8F, 3.7F)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build("void_devourer"));

    private ModEntities() {}
}
