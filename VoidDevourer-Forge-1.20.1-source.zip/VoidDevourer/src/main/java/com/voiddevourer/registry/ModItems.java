package com.voiddevourer.registry;

import com.voiddevourer.VoidDevourerMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VoidDevourerMod.MODID);

    public static final RegistryObject<Item> VOID_DEVOURER_SPAWN_EGG = ITEMS.register(
            "void_devourer_spawn_egg",
            () -> new SpawnEggItem(ModEntities.VOID_DEVOURER, 0x171323, 0x9B36D6,
                    new Item.Properties()));

    private ModItems() {}
}
