package com.voiddevourer.entity;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class DevourerEntity extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("O Devorador do Vazio"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private int attackCooldown = 80;
    private int phase = 1;
    private int phaseTicks = 0;

    public DevourerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 100;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 18.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.85D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        phaseTicks++;
        float healthRatio = getHealth() / getMaxHealth();
        int nextPhase = healthRatio <= 0.30F ? 3 : healthRatio <= 0.65F ? 2 : 1;
        if (nextPhase != phase) {
            phase = nextPhase;
            level().playSound(null, blockPosition(), SoundEvents.WARDEN_ROAR,
                    SoundSource.HOSTILE, 3.0F, phase == 3 ? 0.65F : 0.85F);
            broadcastEntityEvent(this, (byte) 60);
        }

        bossEvent.setProgress(healthRatio);
        bossEvent.setName(Component.literal(phase == 1 ? "O Devorador do Vazio"
                : phase == 2 ? "O Devorador do Vazio — Corrupção"
                : "O Devorador do Vazio — Forma Cósmica"));

        if (tickCount % 5 == 0) {
            level().sendParticles(ParticleTypes.PORTAL,
                    getX(), getY() + 2.0D, getZ(), 8, 0.8D, 1.2D, 0.8D, 0.03D);
            if (phase >= 2) level().sendParticles(ParticleTypes.SCULK_SOUL,
                    getX(), getY() + 1.6D, getZ(), 3, 0.6D, 0.8D, 0.6D, 0.01D);
        }

        if (--attackCooldown <= 0 && getTarget() != null) {
            performVoidAttack();
            attackCooldown = phase == 1 ? 100 : phase == 2 ? 75 : 55;
        }
    }

    private void performVoidAttack() {
        List<Player> victims = level().getEntitiesOfClass(Player.class,
                getBoundingBox().inflate(phase == 3 ? 12.0D : 9.0D),
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
        if (victims.isEmpty()) return;

        if (phase == 1) {
            // Esmagamento: onda de choque curta ao redor do chefe.
            level().playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE,
                    SoundSource.HOSTILE, 2.2F, 0.55F);
            for (Player player : victims) {
                if (distanceTo(player) <= 5.5D) {
                    player.hurt(damageSources().mobAttack(this), 12.0F);
                    player.push((player.getX() - getX()) * 0.8D, 0.45D,
                            (player.getZ() - getZ()) * 0.8D);
                }
            }
            level().sendParticles(ParticleTypes.EXPLOSION,
                    getX(), getY() + 0.4D, getZ(), 3, 1.2D, 0.2D, 1.2D, 0.0D);
        } else if (phase == 2) {
            // Raio do Vazio: dano em linha reta na direção do alvo.
            Player target = victims.stream().min((a, b) -> Double.compare(distanceTo(a), distanceTo(b))).orElse(null);
            if (target == null) return;
            Vec3 start = position().add(0, 2.2D, 0);
            Vec3 direction = target.position().add(0, 1.0D, 0).subtract(start).normalize();
            for (int i = 1; i <= 16; i++) {
                Vec3 point = start.add(direction.scale(i * 1.35D));
                level().sendParticles(ParticleTypes.DRAGON_BREATH,
                        point.x, point.y, point.z, 5, 0.25D, 0.25D, 0.25D, 0.01D);
                AABB hitBox = new AABB(point, point).inflate(0.9D);
                for (Player player : level().getEntitiesOfClass(Player.class, hitBox)) {
                    player.hurt(damageSources().magic(), 9.0F);
                }
            }
            level().playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE,
                    SoundSource.HOSTILE, 2.0F, 0.5F);
        } else {
            // Colapso: explosão cósmica de grande raio, com aviso visual.
            level().playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM,
                    SoundSource.HOSTILE, 3.0F, 0.7F);
            level().sendParticles(ParticleTypes.REVERSE_PORTAL,
                    getX(), getY() + 1.8D, getZ(), 100, 4.5D, 2.0D, 4.5D, 0.08D);
            for (Player player : victims) {
                double distance = distanceTo(player);
                if (distance < 11.0D) {
                    player.hurt(damageSources().magic(), distance < 5.0D ? 22.0F : 14.0F);
                    Vec3 knock = player.position().subtract(position()).normalize().scale(1.3D);
                    player.push(knock.x, 0.65D, knock.z);
                }
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(net.minecraft.world.damagesource.DamageTypes.FALL)) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        // A recompensa especial será adicionada na próxima etapa do conteúdo.
    }
}
