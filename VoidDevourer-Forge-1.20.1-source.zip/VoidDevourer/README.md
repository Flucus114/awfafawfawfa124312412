# Void Devourer — add-on para Sculk Harp

Mod independente para Minecraft Java 1.20.1 + Forge 47. Ele não modifica nem substitui `sculkharp-1.1.0.jar`; os dois mods podem ficar juntos na pasta `mods`.

## Requisitos
- Minecraft Java 1.20.1
- Forge 47.x
- Java 17 para compilar

## Como abrir e compilar
1. Extraia o projeto.
2. Abra a pasta no IntelliJ IDEA ou Eclipse como projeto Gradle.
3. Aguarde o Gradle baixar ForgeGradle e as dependências.
4. Execute `gradlew build` (Windows: `gradlew.bat build`).
5. O JAR será criado em `build/libs/voiddevourer-1.0.0.jar`.
6. Coloque esse JAR e o `sculkharp-1.1.0.jar` em `.minecraft/mods`.

## Teste no mundo
- Use `/summon voiddevourer:void_devourer` para invocar o boss.
- Ou use o ovo de invocação na aba Criativo.

## Conteúdo incluído nesta primeira base
- Entidade própria registrada no Forge.
- Barra de chefe e 500 pontos de vida.
- IA hostil com perseguição e combate corpo a corpo.
- Três fases por porcentagem de vida (100–65%, 65–30%, abaixo de 30%).
- Esmagamento, raio em linha e Colapso em área.
- Modelo 3D inicial feito com ModelPart e textura placeholder.

## Importante
Este é o primeiro pacote-fonte funcional/base do add-on, não uma versão final de produção. A textura incluída é apenas um placeholder; o visual definitivo (UV detalhado, núcleo emissivo, costelas, cristais e chifres), animações avançadas, ritual/altar e recompensas ainda precisam ser implementados. O projeto não foi compilado neste ambiente, então compile no Gradle e envie qualquer erro para correção.
